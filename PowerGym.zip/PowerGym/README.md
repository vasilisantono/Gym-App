# Fire Fitness

Fire Fitness is a web based Gym Management System built on java.
Backend was developed using java.
Front-end was developed in HTML5 using Bootstrap-4 as a css framework and javascript for validation.
System was built as the 2nd year undergraduate project.
