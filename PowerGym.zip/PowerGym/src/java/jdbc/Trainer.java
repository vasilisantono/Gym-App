package jdbc;

public class Trainer {

}
