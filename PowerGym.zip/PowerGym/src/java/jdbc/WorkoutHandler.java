package jdbc;

public class WorkoutHandler {
	private String workout;
	
	public WorkoutHandler(String workout) {
		this.workout = workout;
	}
	
	public String getWorkout() {
		return workout;
	}
	
}
