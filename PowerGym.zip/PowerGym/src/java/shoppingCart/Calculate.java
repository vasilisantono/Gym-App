package shoppingCart;

abstract class Calculate {
    
    public Calculate(){}
    
    public abstract double getTotal();
}
